# from the socket module import all
from socket import *
# from datetime module
from datetime import datetime

import sys
#This is the name of the script: ", sys.argv[0]
#Number of arguments: ", len(sys.argv)
#The arguments are: " , str(sys.argv)

#Validate syntax
if(len(sys.argv)>2  | len(sys.argv)<=1):
    print('Invalid syntax [server_host]')
    exit(0)

server_host =  sys.argv[1]
server_port =   6789
server_address = (gethostbyname(server_host),server_port)

print('\tServer_address: %s' %server_address[0])

# Create a UDP server socket
#(AF_INET is used for IPv4 protocols)
#(SOCK_DGRAM is used for UDP)
sock = socket(AF_INET, SOCK_DGRAM)

#Collect  datetime when connecion was stablished
currentTime = datetime.now().strftime("%H:%M:%S")

#Collect data
messageSent = input('\tEnter a message:: ')
while len(messageSent)<=0:
    messageSent = input('\tPlease enter a valid message:: ')

#Send message to server using unreliable protocol
print('\tSending "%s"' % messageSent)

try:

    # Data is transmitted to the server with sendall()
    # encode() function returns bytes object
    sock.sendto(messageSent.encode(), server_address)
    server_bytes, server_address = sock.recvfrom(2048)
    # Look for the response
    if server_bytes:

    	# Data is read from the socketBuffer with recvfrom()
        # decode() function returns string object
        server_data = server_bytes.decode()

        print('\tReceived: %s' % server_data)

finally:
    print('Closing socket')
    sock.close()
