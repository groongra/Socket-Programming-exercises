# from the socket module import all
from socket import *
# from datetime module
from datetime import datetime

# Create a UDP server socket
#(AF_INET is used for IPv4 protocols)
#(SOCK_DGRAM is used for UDP)
sock = socket(AF_INET, SOCK_DGRAM)
# if we did not import everything from socket, then we would have to write the previous line as:
# sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

hostname = gethostname()
address = gethostbyname(hostname)
# set values for host 'localhost' - meaning this machine and port number 10000
server_address = (hostname, 6789)
# output to terminal some info on the address details
print('*** Server is starting up on "%s", IP:"%s" ***' %(hostname,address))

#Create logfile
file = open("logFile", "w")

# Bind the socket to the host and port
sock.bind(server_address)

# we want the server to run all the time, so set up a forever true while loop
while True:

    # Now the server waits for a connection
    print('*** Waiting for a client ***')

    try:
        # decode() function returns string object
        client_bytes, client_address = sock.recvfrom(2048)
        # collect the system's datetime and parse it into string
        currentTime = datetime.now().strftime("%H:%M:%S")
        logInfo = currentTime + "::"

        if client_bytes:
            print('\tDatagram from client_address',client_address)
            messageRecived = client_bytes.decode()
            logInfo += messageRecived + '\n'

    finally:
            print('\tReceived %s' % messageRecived)

            #log data from client
            file.write(logInfo)

            # Transform data into uppercase
            messageRecived = messageRecived.upper()

            # Encode() function returns bytes object
            sock.sendto(messageRecived.encode(), client_address)
            print('\tSending uppercase data back to client %s: %s' % (client_address,messageRecived))

# now close the socket
sock.close();
