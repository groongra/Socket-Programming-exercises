import threading
import time
# from the socket module import all
from socket import *
# from datetime module
from datetime import datetime

# Create a TCP server socket
#(AF_INET is used for IPv4 protocols)
#(SOCK_STREAM is used for TCP)
sock = socket(AF_INET, SOCK_STREAM)
# if we did not import everything from socket, then we would have to write the previous line as:
# sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

hostname = gethostname();
address = gethostbyname(hostname);
# set values for host 'localhost' - meaning this machine and port number 10000
server_address = (hostname, 10000)
# output to terminal some info on the address details



def thread_function(name,client_address):
    logging.info("Thread %s: starting", name)

    print(' *\tConnection from client_address',client_address)
    print('\tStart packets transmission')
    # collect the system's datetime and parse it into string
    currentTime = datetime.now().strftime("%H:%M:%S")
    logInfo = currentTime + ':: '
    packetsRecived = 0;

    try:

        # Receive the data in small chunks and retransmit it
        while True:
            # decode() function returns string object
            data = connection.recv(16).decode()

            if data:
                print('\tReceived "%s"' % data)
                logInfo += data
                if(packetsRecived == 0): data = currentTime+':'+data
                #increase the packetsRecived counter
                packetsRecived += 1
                # encode() function returns bytes object
                connection.sendall(data.encode())
                print('\tsending data back to client %s: %s' % (client_address,data))

            else:
                print('\tNo more data from client', client_address)
                logInfo += '\n'
                file.write(logInfo)
                break

    finally:
        print(' *\tClose connection\n')
        # Clean up the connection
        connection.close()
    logging.info("Thread %s: finishing", name)

print('*** Server is starting up on %s port(IP: %s)***' % (server_address, address));
#Create logfile
file = open("logFile", "w")

# Bind the socket to the host and port
sock.bind(server_address)

# Listen for one incoming connections to the server
sock.listen(1)

# we want the server to run all the time, so set up a forever true while loop
while True:

    # Now the server waits for a connection
    print('*** Waiting for a connection ***')
    # accept() returns an open connection between the server and client, along with the address of the client
    connection, client_address = sock.accept()
    # when the TCP interrupt operation ocurrs it means that a client has 'knocked' on the 'door' socket in which the server was listening (waiting)

    if __name__ == "__main__":
        format = "%(asctime)s: %(message)s"
        logging.info("Main    : before creating thread")
        newClient = threading.Thread(target=thread_function, args=(1,))
        logging.info("Main    : before running thread")
        newClient.start()
        logging.info("Main    : wait for the thread to finish")
        newClient.join()
        logging.info("Main    : all done")


# now close the socket
sock.close();
