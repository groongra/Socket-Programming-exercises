# from the socket module import all
from socket import *
# from datetime module
from datetime import datetime

#import sys args
import sys
#This is the name of the script: ", sys.argv[0]
#Number of arguments: ", len(sys.argv)
#The arguments are: " , str(sys.argv)

#Validate syntax
if(len(sys.argv)>3  | len(sys.argv)<=1):
    print('Invalid syntax [server_host] [server_port] [filename]')
    exit(0)

server_host =  sys.argv[1]
server_port =  int(sys.argv[2])
filename = sys.argv[3]

print('\tServer_host: %s' %server_host)
print('\tSserver_port: %s' %server_port)
print('\tFilename: %s' %filename)

# Create a TCP server socket
#(AF_INET is used for IPv4 protocols)
#(SOCK_STREAM is used for TCP)
sock = socket(AF_INET, SOCK_STREAM)

#To connect via TCP we use a tuple of IP and Port
server_tuple = (server_host, server_port)

# output to terminal some info on the address details
print('\tConnecting to server at IP %s with port number %s' %(server_host, server_port))

# Connect the socket to the host and port
sock.connect(server_tuple)
try:

    # HTTP protcol indicates HttpCommand /FilenameRequested HttpVersion \r\n\r\n -> i.e: GET /HelloWorld.html HTTP/1.1

    # Build an HTTP GET request.
    messageHeader = 'GET'
    messageHttpVersion = 'HTTP/1.1'
    messageGetRequest = messageHeader+' /'+filename+' '+messageHttpVersion+'\r\n\r\n'

    # Send HTTP GET request.
    print('\tSending %s' % messageGetRequest)

    # Data is transmitted to the server with sendall()
    # encode() function returns bytes object
    sock.sendall(messageGetRequest.encode())

    # Look for the response. Loop until the connection is closed by the server, meaning the data transmission has finnished
    requested_file = ''
    while True:
        server_response = sock.recv(1024).decode()
        if server_response:
            requested_file += server_response
        else:
            break

finally:
    # Display all the information recived
    print(requested_file)

    print('Closing socket')
    sock.close()
