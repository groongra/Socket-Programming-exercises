# from the socket module import all
from socket import *
# from datetime module
from datetime import datetime

# Create a TCP server socket
#(AF_INET is used for IPv4 protocols)
#(SOCK_STREAM is used for TCP)
sock = socket(AF_INET, SOCK_STREAM)

# set values for host 'localhost' - meaning this machine and port number 10000
# the machine address and port number have to be the same as the server is using.
#hostname = gethostname();
hostname = gethostname()
address = gethostbyname(hostname)
server_address = (hostname, 10000)
# output to terminal some info on the address details
print('Connecting from client %s (IP: %s)' %(hostname , address))
print('Connecting to server at %s port %s' % server_address)
# Connect the socket to the host and port
sock.connect(server_address)
while True:
    #Send message
    try:
        #Collect datetime when message was sent
        currentTime = datetime.now().strftime("%H:%M:%S")
        messageSent = input('\tEnter a message:: ')
        while len(messageSent)<=0:
            messageSent = input('\tPlease enter a valid message:: ')

        # Send data
        print('\tSending "%s"' %messageSent)
        # Data is transmitted to the server with sendall()
        # encode() function returns bytes object
        sock.sendall(messageSent.encode())
        # Look for the response
        dataReceived = ""
        amount_received = 0
        amount_expected = len(currentTime + messageSent)
        while amount_received < amount_expected:
        	# Data is read from the connection with recv()
            # decode() function returns string object
            data = sock.recv(16).decode()
            dataReceived += data
            amount_received += len(data)
        print('\tReceived "%s"' %dataReceived)

    finally:
        endMessage = "<END>"
        sock.sendall(endMessage.encode())
        print('<"%s">' %messageSent)

    #Listen to response
    try:
        # collect the system's datetime and parse it into string
        currentTime = datetime.now().strftime("%H:%M:%S")
        messageRecived = '';
        packetsRecived = 0;

        # Receive the data in small chunks and retransmit it
        while True:
            # decode() function returns string object
            data = sock.recv(16).decode()

            if (data!="<END>"):
                print('\tReceived "%s"' %data)
                messageRecived += data
                if(packetsRecived == 0): data = currentTime+':'+data
                #increase the packetsRecived counter
                packetsRecived += 1
                # encode() function returns bytes object
                print('\tSending "%s"' %data)
                sock.sendall(data.encode())
            else:
                print('\tNo more data from Server')
                break
    finally:
        print('<"%s">' %messageRecived)

print('Closing socket')
sock.close()
