# from the socket module import all
from socket import *
# from datetime module
from datetime import datetime

# Create a TCP server socket
#(AF_INET is used for IPv4 protocols)
#(SOCK_STREAM is used for TCP)
sock = socket(AF_INET, SOCK_STREAM)
# if we did not import everything from socket, then we would have to write the previous line as:
# sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

hostname = gethostname();
address = gethostbyname(hostname);
# set values for host 'localhost' - meaning this machine and port number 10000
server_address = (hostname, 10000)
# output to terminal some info on the address details
print('*** Server is starting up on %s port(IP: %s)***' % (server_address, address));
#Create logfile
file = open("logFile", "w")

# Bind the socket to the host and port
sock.bind(server_address)

# Listen for one incoming connections to the server
sock.listen(1)

# we want the server to run all the time, so set up a forever true while loop
while True:

    # Now the server waits for a connection
    print('*** Waiting for a connection ***')
    # accept() returns an open connection between the server and client, along with the address of the client
    connection, client_address = sock.accept()
    # when the TCP interrupt operation ocurrs it means that a client has 'knocked' on the 'door' socket in which the server was listening (waiting)
    print(' *\tConnection from client_address',client_address)

    while True: #chat

        #Listen for message
        try:
            # collect the system's datetime and parse it into string
            currentTime = datetime.now().strftime("%H:%M:%S")
            logInfo = currentTime + ':: '
            messageRecived = '';
            packetsRecived = 0;

            # Receive the data in small chunks and retransmit it
            while True:
                # decode() function returns string object
                data = connection.recv(16).decode()

                if (data!="<END>"):
                    print('\tReceived "%s"' % data)
                    messageRecived += data
                    logInfo += data
                    if(packetsRecived == 0): data = currentTime+':'+data
                    #increase the packetsRecived counter
                    packetsRecived += 1
                    # encode() function returns bytes object
                    connection.sendall(data.encode())
                    print('\tSending "%s"' %data)

                else:
                    print('\tNo more data from client')
                    break
        finally:
            logInfo += '\n'
            file.write(logInfo)
            print('<"%s">'%messageRecived)

        try:
            #response
            #Collect data
            messageSent = input('\tEnter a message:: ')
            while len(messageSent)<=0:
                messageSent = input('\tPlease enter a valid message:: ')

            # Send data
            print('\tSending "%s"' %messageSent)
            # Data is transmitted to the server with sendall()
            # encode() function returns bytes object
            connection.sendall(messageSent.encode())
            # Look for the response

            dataReceived = ""
            amount_received = 0
            amount_expected = len(currentTime + messageSent)

            while amount_received < amount_expected:
            	# Data is read from the connection with recv()
                # decode() function returns string object
                data = connection.recv(16).decode()
                dataReceived += data
                amount_received += len(data)
            print('\tReceived "%s"' % dataReceived)
        finally:
            print('<"%s">'%messageSent)
            endMessage = "<END>"
            connection.sendall(endMessage.encode())

# now close the socket
sock.close();
